import pygame
from pygame.locals import *

from OpenGL.GL import *
from OpenGL.GLU import *

import cv2
import numpy as np
import math
import random
import sys
import random
from random import randrange
from camera import *
from target import *

from egl import *
from objloader import *

def compute_matrix(rect, index, camera_matrix, dist_coeffs):
    """
    :param rect: list of points of a target
    :param index: indexs of this points
    :param dist_coeffs: distortion coefficients
    """
    idx = index.copy()
    v = idx[-1]
    idx.insert(0,v)
    idx = idx[0:4]
    imagePoints = np.array(rect, dtype="float32")
    objectPoints = np.array([[-1, -1, 1], [ 1, -1, 1], [ 1,  1, 1], [-1,  1, 1]], dtype="float32")
    _, rvecs, tvecs = cv2.solvePnP(objectPoints[idx], imagePoints, camera_matrix, dist_coeffs)
    rot_mat, _ = cv2.Rodrigues(rvecs)
    return np.transpose(np.array([
        [ rot_mat[0][0],  rot_mat[0][1],  rot_mat[0][2],  tvecs[0]], 
        [-rot_mat[1][0], -rot_mat[1][1], -rot_mat[1][2], -tvecs[1]], 
        [-rot_mat[2][0], -rot_mat[2][1], -rot_mat[2][2], -tvecs[2]], 
        [           0.0,            0.0,            0.0,       1.0]]
    ))


def pikachu(obj,m,cam_x,cam_y):
    glDepthMask(GL_TRUE)
    glEnable(GL_DEPTH_TEST)
    glPushMatrix()
    glLoadMatrixd(m)
    glTranslate(-0.1,0,0)
    glCallList(obj.gl_list)
    glPopMatrix()
    glDisable(GL_DEPTH_TEST)



def world_to_video_coord(coord, width, height,scale = 1):
    x = coord.x * scale
    y = ((coord.y * (-1)) + height) * scale
    z = coord.z
    return Coord(x,y,z)

def draw_rect(c1,c2,c3,c4, color = COLOR_PINK, scale = 1):
    eglSetHexColor(color)
    glBegin(GL_POLYGON)     
    glVertex3f(c1.x,c1.y,c1.z)
    glVertex3f(c2.x,c2.y,c2.z)
    glVertex3f(c3.x,c3.y,c3.z)
    glVertex3f(c4.x,c4.y,c4.z)
    glEnd()

def draw_tri(c1,c2,c3,color = COLOR_PINK, scale = 1):
    eglSetHexColor(color)
    glBegin(GL_POLYGON)     
    glVertex3f(c1.x,c1.y,c1.z)
    glVertex3f(c2.x,c2.y,c2.z)
    glVertex3f(c3.x,c3.y,c3.z)
    glEnd()

def draw_ori(quad,ori,color = COLOR_CYAN, scale = 1):

    ori0 = [0,1,2,3]
    ori1 = [3,0,1,2]
    ori2 = [2,3,0,1]
    ori3 = [1,2,3,0]

    # quad[0].round(1)
    # quad[1].round(1)
    # quad[2].round(1)
    # quad[3].round(1)
    
    # print(str(quad[0]*10) + ", " + str(quad[1]*10) + ", " + str(quad[2]*10) + ", " + str(quad[3]*10))
    # print(ori)

    col_sum_1 = quad[0].x + quad[1].x  + quad[2].x  + quad[3].x 
    col_sum_2 = quad[0].y + quad[1].y  + quad[2].y  + quad[3].y
    col_sum_3 = quad[0].z + quad[1].z  + quad[2].z  + quad[3].z
    avg = Coord(col_sum_1/4,col_sum_2/4,col_sum_3/4 + 0.01)

    if ori == ori0:
        draw_tri(quad[3],quad[0],avg,color = color, scale = scale)
    elif ori == ori1:
        draw_tri(quad[0],quad[1],avg,color = color, scale = scale)
    elif ori == ori2:
        draw_tri(quad[1],quad[2],avg,color = color, scale = scale)
    elif ori == ori3:
        draw_tri(quad[2],quad[3],avg,color = color, scale = scale)


def draw_circle(c, radius = 1, sides = 6, color = COLOR_RED, scale = 1):
    eglSetHexColor(color)
    glBegin(GL_POLYGON)     
    for i in range(sides):
        angle = (2 * math.pi * i) / sides
        x = math.cos(angle) * radius
        y = math.sin(angle) * radius
        glVertex3f(c.x + x, c.y + y,c.z)
    glEnd()

def draw_rect_with_tex(tex, width  : int = 100, height : int = 100, scale = 1):
    textureSurface = tex
    textureData = pygame.image.tostring(textureSurface, "RGBA", 1)
    width = textureSurface.get_width()
    height = textureSurface.get_height()

    glEnable(GL_TEXTURE_2D)
    texid = glGenTextures(1)

    glBindTexture(GL_TEXTURE_2D, texid)
    glTexImage2D(GL_TEXTURE_2D, 0, GL_RGB, width, height, 0, GL_RGBA, GL_UNSIGNED_BYTE, textureData)
    glTexParameterf(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT)
    glTexParameterf(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_REPEAT)
    glTexParameterf(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_NEAREST)
    glTexParameterf(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_NEAREST)

    glBegin(GL_QUADS)
    glTexCoord2f(0.0, 0.0); glVertex3f( 0, 0, 0)
    glTexCoord2f(1.0, 0.0); glVertex3f( width*scale, 0, 0)
    glTexCoord2f(1.0, 1.0); glVertex3f( width*scale, height*scale, 0)
    glTexCoord2f(0.0, 1.0); glVertex3f( 0, height*scale, 0)
    glEnd()

    glDisable(GL_TEXTURE_2D)

    return texid

def drawText(position, textString, size):     
    pygame.init() # now use display and fonts
    font = pygame.font.Font (None, size)
    textSurface = font.render(textString, True, (0,0,0,0),(255,255,255,255))     
    textData = pygame.image.tostring(textSurface, "RGBA", True)     
    glRasterPos3d(*position)   
    glDrawPixels(textSurface.get_width(), textSurface.get_height(), GL_RGBA, GL_UNSIGNED_BYTE, textData)

def draw_ground(size,color,height):
    eglSetHexColor(color)
    glBegin(GL_POLYGON)     
    glVertex3f(size,size*(-1),height)
    glVertex3f(size*(-1),size*(-1),height)
    glVertex3f(size*(-1),size,height)
    glVertex3f(size,size,height)
    glEnd()
    
# Soruce : https://stackoverflow.com/questions/19306211/opencv-cv2-image-to-pygame-image
def cvimage_to_pygame(image):
    return pygame.image.frombuffer(image.tostring(), image.shape[1::-1],"RGB")


def draw_axis():
    axis_distance = 10000
    # X AXIS
    eglLine((0,0,0),(axis_distance,0,0),COLOR_BLUE)
    eglLine((0,0,0),((-1)*axis_distance,0,0),COLOR_LIGHT_BLUE)
    
    # Y AXIS
    eglLine((0,0,0),(0,axis_distance,0),COLOR_GREEN)
    eglLine((0,0,0),(0,(-1)*axis_distance,0),COLOR_LIGHT_GREEN)

    # Z AXIS 
    eglLine((0,0,0),(0,0,axis_distance),COLOR_RED)
    eglLine((0,0,0),(0,0,(-1)*axis_distance),COLOR_LIGHT_RED)

def draw_cage():
    eglLine((10,10,0),(10,10,10),"#2A713C")
    eglLine((10,-10,0),(10,-10,10),"#2A713C")
    eglLine((-10,10,0),(-10,10,10),"#2A713C")
    eglLine((-10,-10,0),(-10,-10,10),"#2A713C")
    eglLine((10,10,10),(10,-10,10),"#2A713C")
    eglLine((10,-10,10),(-10,-10,10),"#2A713C")
    eglLine((-10,-10,10),(-10,10,10),"#2A713C")
    eglLine((-10,10,10),(10,10,10),"#2A713C")

def draw_grid():
    repeat = 50
    size = 1

    height = 0.01

    for i in range(1,repeat):
        axis_distance = repeat
        origin_distance = size*i
        # Paralel to the X AXIS
        color = COLOR_BLACK
        eglLine((0,origin_distance,height),(axis_distance,origin_distance,height),color)
        eglLine((0,origin_distance,height),((-1)*axis_distance,origin_distance,height),color)
        eglLine((0,-origin_distance,height),(axis_distance,-origin_distance,height),color)
        eglLine((0,-origin_distance,height),((-1)*axis_distance,-origin_distance,height),color)

        # Paralel to the Y AXIS
        color = COLOR_BLACK
        eglLine((origin_distance,0,height),(origin_distance,axis_distance,height),color)
        eglLine((origin_distance,0,height),(origin_distance,(-1)*axis_distance,height),color)
        eglLine((-origin_distance,0,height),(-origin_distance,axis_distance,height),color)
        eglLine((-origin_distance,0,height),(-origin_distance,(-1)*axis_distance,height),color)
        

def IdentityMat44(): 
    return np.matrix(np.identity(4), copy=False, dtype='float32')

def main():

    video_path = "resources/entrada.mp4"
    wait = 1
    # Setting up the window dimensions according to video
    video = cv2.VideoCapture(video_path)
    hasFrame, frame = video.read()
    if not hasFrame : 
        print("Video inválido")
        exit()
    h,w = frame.shape[:2]
    video_dimensions = { "width" : w, "height" : h }
    print(video_dimensions)
    video_scale_in_world =  0.01

    screen_scale = 1.3
    display = (math.ceil(video_dimensions["width"]*screen_scale),math.ceil(video_dimensions["height"]*screen_scale))
    
    print ("Display: " + str(display))

    pygame.init()
    pygame.display.set_mode(display,DOUBLEBUF|OPENGL)
    pygame.mouse.set_visible(True)
    glEnable(GL_DEPTH_TEST)
    glMatrixMode(GL_PROJECTION)
    gluPerspective(47, display[0]/display[1], 0.1, 1000)
    view_mat = IdentityMat44()
    glMatrixMode(GL_MODELVIEW)
    glLoadIdentity()
    glGetFloatv(GL_MODELVIEW_MATRIX, view_mat)
    glLoadIdentity()

    max_dim = max(video_dimensions["height"],video_dimensions["width"])
    cam_x = (video_dimensions["width"]/2)*video_scale_in_world
    cam_y = (video_dimensions["height"]/2)*video_scale_in_world
    camera = Camera( (cam_x,cam_y,(5.5/640)*max_dim) , (cam_x,cam_y+0.01,0) , (0,0,1))
    # camera.lock()

    pikachu_obj = OBJ("resources/pikachu/Pikachu.obj", swapyz=True)
    video = cv2.VideoCapture(video_path)
    target_searcher = TargetSearcher("resources/alvo.jpg")

    lock_camera_pos = False
    lock_camera_aim = False
    last_markers = []
    last_markers_count = 0
    last_markers_max = 5

    keepRunning = True
    while keepRunning:

        pygame.display.flip()
        pygame.time.wait(wait)
        pygame.event.pump()

        glMatrixMode(GL_MODELVIEW)
        glPushMatrix()
        glLoadIdentity()

        glMultMatrixf(view_mat)
        glGetFloatv(GL_MODELVIEW_MATRIX, view_mat)
        
        # Background Color
        t = eglHexToTuple("#70CCFF")
        glClearColor(t[0],t[1],t[2],0.1)
        glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT)


        # Camera control
        camera.control(speed = 0.2)

        # input()
        # Reading one frame for the video
        # If the video ends, we'll play it again
        hasFrame, frame = video.read()
        if not hasFrame: 
            video = cv2.VideoCapture(video_path)
            hasFrame, frame = video.read()
            # print("Hit/Miss = " + str(target_searcher.hit) + "/" + str(target_searcher.miss) +  ", " + str(target_searcher.hit/target_searcher.miss))
            target_searcher.miss = 0
            target_searcher.hit = 0
            # print("\n\n==============================================")
        frame = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)

        draw_axis()
        draw_cage()
        draw_rect_with_tex(cvimage_to_pygame(frame), scale = video_scale_in_world)
    
        markers = target_searcher.search(frame)
        if len(markers) == 0 and last_markers_count > 0:
            markers = last_markers
            last_markers_count-=1
        else:
            last_markers = markers
            last_markers_count=last_markers_max
        for m in markers:
            corners = m[0]
            orientation = m[1]
            quad = [ world_to_video_coord(Coord(c[0],c[1],0.05),video_dimensions["width"],video_dimensions["height"],scale = video_scale_in_world) for c in corners]
            # draw_rect(quad[0], quad[1], quad[2], quad[3])
            # draw_ori(quad,orientation)
            fx = fy = 540
            cx, cy = 340, 250
            cameraMatrix = np.array([[fx, 0, cx], [0, fy, cy], [0, 0, 1]])
            distCoeffs = np.array([0.07, -0.04, 0, 0, 0])
            distCoeffs = np.array([0.07, -0.08, 0, 0, 0])
            matrix = compute_matrix(corners, orientation, cameraMatrix, distCoeffs)
            pikachu(pikachu_obj,matrix,cam_x,cam_y)
        
        glPopMatrix()


        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                keepRunning = False
    

if __name__ == "__main__":
    main()