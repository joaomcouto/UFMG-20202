import cv2
import numpy as np
from collections import deque
import random


def pearson_correlation(x, y):
    std_prod = x.std() * y.std()
    if std_prod == 0:
        return 0
    else:
        return np.mean((x - x.mean()) * (y - y.mean())) / std_prod

def correlation_coefficient(patch1, patch2):
    product = np.mean((patch1 - patch1.mean()) * (patch2 - patch2.mean()))
    stds = patch1.std() * patch2.std()
    if stds == 0:
        return 0
    else:
        product /= stds
        return product


class TargetSearcher:
    
    def __init__(self, target_filename):
        
        self.target_already_adjusted = False
        self.target_filename = target_filename
        self.saved_warps = 0

    def setup_target(self,img_width,img_height):

        max_dim = max(img_width,img_height)

        # Target image dimensions
        self.target_size = round((max_dim / 6)/10)*5
        
        # Parsing target image : loading, resizing it and converting it to black and white
        self.target = cv2.imread(self.target_filename)
        self.target = cv2.resize(self.target, (self.target_size, self.target_size), interpolation = cv2.INTER_AREA)
        self.target = cv2.cvtColor(self.target, cv2.COLOR_BGR2GRAY)
        _, self.target = cv2.threshold(self.target, 128, 255, cv2.THRESH_BINARY)

        self.last_points=[]
        self.found = False
        self.miss = 0
        self.hit = 0

        self.target_already_adjusted = True

    def quads_are_similar(self,quad1,quad2,threshold):
            for c1 in quad1: # mc is a coordinate
                for c2 in quad2: # cn is also a coordinate
                    if (abs(c2[0] - c1[0]) < threshold) or (abs(c2[1] - c1[1]) < threshold):
                        return True
    
    def search(self, frame):

        ori = [
            [0,1,2,3],
            [3,0,1,2],
            [2,3,0,1],
            [1,2,3,0]
        ]

        # Parsing frame : Converting to black and white so we can detect the edges faster
        img = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
        _, img = cv2.threshold(img, 128, 255, cv2.THRESH_BINARY)

        if not self.target_already_adjusted:
            self.setup_target(img.shape[:2][1],img.shape[:2][0])

        # Getting the edged version of the frame after applying the Canny algorithm 
        edged = cv2.Canny(img, 100, 200)
        # Getting the countours. Each countor is a list of touples defining the boundary points.
        countours, _ = cv2.findContours(edged, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)

        markers = []
        for c in countours:
            # Finding the aproximated shape of this countour
            # We'll use a constant value for epsilon since it is to costly to run
            approx = cv2.approxPolyDP(c, 12, True)
            # If the lenght of the aproximated shape is 4, it means that we' may have found a quadrilateral, 
            # Which is ideal for the situation
            
            if len(approx) == 4:
                approx = approx[0:4]
                target_vertices = np.array([[0, 0], [0, self.target_size], [self.target_size, self.target_size], [self.target_size, 0]], dtype="float32")

                # Transforming the shape in a list of corner coordinates, since it is a quadrilateral
                corners = np.around(np.array(approx.reshape(4,2), dtype="float32"),1)

                found_similar_coord = False
                for m in markers: # m[0] is a list of of corner coordinates
                    if self.quads_are_similar(corners,m[0],5):
                        found_similar_coord = True
                        break

                if found_similar_coord:
                    continue

                found_rot = False
                best_ori = None
                best_avg = None
                best_corners = None
                # For each possible rotation we'll see if it matches, so : 
                last_best_correlation = 0
                for i in range(4):
                    # We get the perspectiveTranformation matrix, with: 
                    #   corners being the "source" points. 
                    #   target_vertices being the mapping of the corners to the new image
                    # After warping it, everything inside the image wil be "stretched" to fit 
                    # into the box defined by target_vertices
                    # It may as well rotate it, depending on the order of those vertices
                    tvo = target_vertices.copy()
                    matrix = cv2.getPerspectiveTransform(corners, tvo[ori[i]])
                    warped = cv2.warpPerspective(img, matrix, (self.target_size, self.target_size))
                    # With this, we already have an image that we can compare to our target
                    # We'll make it binary (black and white, not grayscale) : 
                    _, bw_img = cv2.threshold(warped, 128, 255, cv2.THRESH_BINARY)
                    # Now we compare it to the rotated target
                    pc = round(pearson_correlation(bw_img, self.target),4)
                    # pc = float(cv2.matchTemplate(bw_img,self.target,cv2.TM_CCOEFF_NORMED)[0][0])


                    threshhold = 0.6
                    # We them will favor more those target who were found in a 
                    # similar position to previous targets
                    col_sum = np.sum(corners, axis=0)
                    avg = np.array([col_sum[0]/4,col_sum[1]/4])
                    tolerance = 0
                    if pc < threshhold and tolerance > 0:
                        for lp in self.last_points:
                            dist = abs(np.linalg.norm(avg-lp))
                            if dist < 10: 
                                tolerance = threshhold/1.9
                                break
    
                    if (pc >= (threshhold - tolerance)):
                        if pc > last_best_correlation:
                            best_corners = corners
                            best_ori = ori[i].copy()
                            best_avg = avg
                            found_rot = True
                            last_best_correlation = pc

                    
                if found_rot:
                    markers.append((best_corners, list(best_ori)))
                    if len(self.last_points) > 50 :
                        self.last_points.pop(-1)
                    self.last_points.insert(random.randint(0,len(self.last_points)),best_avg)

        if len(markers) == 0 :
            if self.found:
                self.miss+=1
            if len(self.last_points) > 0 :
                self.last_points.pop(-1)
            self.found = False
        else:
            self.hit+=1
            self.found = True

        return markers

